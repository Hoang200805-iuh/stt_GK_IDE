import requests
from bs4 import BeautifulSoup
import time

def crawl_smashing_articles_with_author(n=5):
    base_url = "https://www.smashingmagazine.com"
    url = base_url + "/articles/"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    response = requests.get(url, headers=headers)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")

    articles = soup.select("article.article--post")[:n]
    results = []

    for article in articles:
        # URL & Title
        link_tag = article.select_one("h2 a")
        title = link_tag.get_text(strip=True) if link_tag else "No title"
        relative_url = link_tag["href"] if link_tag else ""
        full_url = relative_url if relative_url.startswith("http") else base_url + relative_url

        # Time
        time_tag = article.select_one("time")
        time_posted = time_tag.get("datetime") if time_tag else "N/A"

        # Summary (nhiều bài không có)
        summary_tag = article.select_one("div.article--post__teaser")
        summary = summary_tag.get_text(strip=True) if summary_tag else "No summary"

        # 👉 Truy cập trang chi tiết để lấy tác giả
        detail_resp = requests.get(full_url, headers=headers)
        detail_resp.raise_for_status()
        detail_soup = BeautifulSoup(detail_resp.text, "html.parser")

        author_tag = detail_soup.select_one("span.author__name")
        author = author_tag.get_text(strip=True) if author_tag else "N/A"

        results.append({
            "title": title,
            "url": full_url,
            "summary": summary,
            "time": time_posted,
            "author": author
        })

        time.sleep(1)

    return results


# In kết quả
if __name__ == "__main__":
    posts = crawl_smashing_articles_with_author()
    for i, post in enumerate(posts, 1):
        print(f"{i}. {post['title']}")
        print(f"   URL: {post['url']}")
        print(f"   Summary: {post['summary']}")
        print(f"   Time: {post['time']}")
        print(f"   Author: {post['author']}\n")
