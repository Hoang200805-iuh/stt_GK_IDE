import requests
from bs4 import BeautifulSoup
import psycopg2
from psycopg2 import sql
import time
from datetime import datetime

# ---------------- PostgreSQL Config ----------------
DB_CONFIG = {
    'dbname': 'airflow',
    'user': 'airflow',
    'password': 'airflow',
    'host': 'localhost',
    'port': 5432,
}

# ---------------- Connect & Create Table ----------------
conn = psycopg2.connect(**DB_CONFIG)
cur = conn.cursor()

cur.execute("""
    CREATE TABLE IF NOT EXISTS smashing_articles (
        id SERIAL PRIMARY KEY,
        title TEXT,
        url TEXT UNIQUE,
        summary TEXT,
        time TIMESTAMP,
        author TEXT
    );
""")
conn.commit()

# ---------------- Crawl ----------------
base_url = "https://www.smashingmagazine.com"
url = base_url + "/articles/"
headers = {
    "User-Agent": "Mozilla/5.0"
}

response = requests.get(url, headers=headers)
response.raise_for_status()
soup = BeautifulSoup(response.text, "html.parser")

articles = soup.select("article.article--post")[:5]

for article in articles:
    link_tag = article.select_one("h2 a")
    title = link_tag.get_text(strip=True) if link_tag else "No title"
    relative_url = link_tag["href"] if link_tag else ""
    full_url = relative_url if relative_url.startswith("http") else base_url + relative_url

    time_tag = article.select_one("time")
    time_posted = time_tag.get("datetime") if time_tag else None
    time_posted = datetime.fromisoformat(time_posted) if time_posted else None

    summary_tag = article.select_one("div.article--post__teaser")
    summary = summary_tag.get_text(strip=True) if summary_tag else "No summary"

    detail_resp = requests.get(full_url, headers=headers)
    detail_resp.raise_for_status()
    detail_soup = BeautifulSoup(detail_resp.text, "html.parser")

    author_tag = detail_soup.select_one("span.author__name")
    author = author_tag.get_text(strip=True) if author_tag else "N/A"

    # ---------------- Insert into DB ----------------
    try:
        cur.execute("""
            INSERT INTO smashing_articles (title, url, summary, time, author)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (url) DO NOTHING;
        """, (title, full_url, summary, time_posted, author))
        conn.commit()
        print(f"✅ Saved: {title}")
    except Exception as e:
        print(f"❌ Error saving {title}: {e}")
        conn.rollback()

    time.sleep(1)

# ---------------- Close DB ----------------
cur.close()
conn.close()
