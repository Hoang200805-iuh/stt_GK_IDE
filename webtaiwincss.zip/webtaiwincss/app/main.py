import os
import time
import requests
from bs4 import BeautifulSoup
import psycopg2
from datetime import datetime

# Kết nối PostgreSQL
conn = psycopg2.connect(
    dbname=os.getenv('DB_NAME'),
    user=os.getenv('DB_USER'),
    password=os.getenv('DB_PASSWORD'),
    host=os.getenv('DB_HOST'),
    port=os.getenv('DB_PORT')
)
cur = conn.cursor()

# Tạo bảng
cur.execute("""
    CREATE TABLE IF NOT EXISTS smashing_articles (
        id SERIAL PRIMARY KEY,
        title TEXT,
        url TEXT UNIQUE,
        summary TEXT,
        time TIMESTAMP,
        author TEXT
    );
""")
conn.commit()

# Crawl dữ liệu
base = 'https://www.smashingmagazine.com'
res = requests.get(base + '/articles/', headers={'User-Agent': 'Mozilla/5.0'})
soup = BeautifulSoup(res.text, 'html.parser')

for art in soup.select('article.article--post')[:5]:
    a = art.select_one('h2 a')
    t = a.get_text(strip=True)
    u = base + a['href']

    sm = art.select_one('div.article--post__teaser')
    s = sm.get_text(strip=True) if sm else 'No summary'

    ti = art.select_one('time')
    dt = datetime.fromisoformat(ti['datetime']) if ti else None

    det = requests.get(u, headers={'User-Agent': 'Mozilla/5.0'})
    d_soup = BeautifulSoup(det.text, 'html.parser')
    au = d_soup.select_one('span.author__name')
    author = au.get_text(strip=True) if au else 'N/A'

    cur.execute("""
        INSERT INTO smashing_articles (title, url, summary, time, author)
        VALUES (%s, %s, %s, %s, %s)
        ON CONFLICT (url) DO NOTHING;
    """, (t, u, s, dt, author))
    conn.commit()
    print("✅ Saved:", t)
    time.sleep(1)

cur.close()
conn.close()
