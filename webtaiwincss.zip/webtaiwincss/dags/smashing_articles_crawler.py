from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id="smashing_articles_crawler",
    default_args=default_args,
    description='Crawl Smashing Magazine articles and save to PostgreSQL',
    schedule_interval='0 10 * * *',  # Mỗi ngày lúc 10h sáng
    start_date=datetime(2025, 4, 10),
    catchup=False,
    tags=['smashing', 'crawler'],
) as dag:

    run_crawler = BashOperator(
        task_id='run_python_crawler',
        bash_command='docker exec webtaiwincss-app-1 python /app/main.py',
    )

    run_crawler
